/*
Se desea efectuar un programa para una estaci�n de peaje.

El programa deber� solicitar al operador de la cabina de peaje la categor�a del veh�culo, el d�a de la semana, el horario, y el importe de dinero entregado por el conductor del veh�culo.
-	Categor�as de veh�culo: moto, auto, camioneta y cami�n.
-	D�as de la semana: 1 (lunes), 2 (martes), 3 (mi�rcoles), 4 (jueves), 5 (viernes), 6 (s�bado), 7 (domingo).
-	Horario: a (pico), b (no pico).

-	Importes a cobrar:
Categor�a de veh�culo	Valor base de calculo	Lunes a Viernes horario pico	Lunes a Viernes horario no pico	S�bados y Domingos horario pico o no pico
moto	                      5	                +20%	        -20%	              -20%
auto	                     10	                +20%	        -20%	              -20%
camioneta	                 15	                +20%	        -20%	              -20%
camion	                     20	                +20%	        -20%	              -20%


El programa le deber� devolver al operador de la cabina de peaje el importe a cobrar (dependiendo de la categor�a del veh�culo, del d�a de la semana y del horario), y el vuelto a entregar al conductor del veh�culo (dependiendo del importe de dinero entregado por el conductor del veh�culo).  

Luego de cada venta, el programa debe preguntarle al operador si desea continuar vendiendo � no.



Todos los mensajes que se muestren por pantalla deben estar prolijamente ordenados y distribuidos.


Cuando el operador decida terminar de vender, el programa deber� informar lo siguiente: 
Cantidad de ventas de categor�a auto en horario pico.
Total de pases vendidos y total recaudado.

No se pide:
Validaci�n de entradas, asumimos que el operador ingresa todos los datos de forma correcta.

*/

#include<stdio.h>
#include<conio.h>
//#include<string.h>
//#include<stdlib.h>

main()
{
      int  dia, hora,cont=0,cont2=0;
      float pago, precio, vuelto,acu=0;
      char inicio[3]={"si"},movil[10]; 
      
      while (!strcmp("si",inicio))
      {
            printf("||||||||||||||||||\n");
            printf("||PROGRAMA PEAJE||\n");
            printf("||||||||||||||||||\n");
            printf("\n");
            printf("MENU DIAS DE LA SEMANA\n");
            printf("***********************\n");
            printf(" Opcion \n1-Lunes\n2-Martes\n3-Miercoles\n4-Jueves\n5-Viernes\n6-Sabado\n7-Domingo\n\n");
            printf("Ingrese un dia de la semana: \n");
            scanf("%i",&dia);
            system("CLS");
            
            printf("MENU TIPO DE VEHICULO\n");
            printf("***********************\n");
            printf(" Opciones \nMoto\nAuto\nCamioneta\nCamion \n\n");
            printf("Ingrese el Vehiculo: \n");
            fflush(stdin);
            gets(movil);
            system("CLS");
            
            printf("Ingrear horario(Pico - 1 / No Pico - 2) \n" );
            scanf("%i",&hora);
            printf("Ingrese el Monto con el que paga en cliente: ");
            scanf("%f",&pago);
            
            switch(dia)
            {
                 case 1:
                 case 2:
                 case 3:
                 case 4:
                 case 5:
                      if ((strcmp(movil,"Moto")==0)&&(hora==1)){precio=5*1.2;}
                      else if(strcmp(movil,"Moto")==0){precio=5*0.8;}
                      
                      if ((strcmp("Auto",movil)==0)&&(hora==1))
                      {
                          precio=10*1.2;
                          cont++;
                      }
                      else if (strcmp("Auto",movil)==0){precio=10*0.8;}
                      
                      if ((strcmp(movil,"Camioneta")==0)&&(hora==1)){precio=15*1.2;}
                      else if (strcmp("Camioneta",movil)==0){precio=15*0.8;}
                      
                      if ((strcmp(movil,"Camion")==0)&&(hora==1)){precio=5*1.2;}
                      else if(strcmp(movil,"Camion")==0){precio=20*0.8;}
                      
                      break;
                 case 6:
                 case 7:
                      if (strcmp(movil,"Moto")==0){precio=5*0.8;}
                      
                      if ((strcmp(movil,"Auto")==0)&&(hora==1))
                      {
                          precio=10*0.8;
                          cont++;
                      }
                      else{precio=10*0.8;}
                      
                      if (strcmp(movil,"Camioneta")==0){precio=15*0.8;}
                      
                      if (strcmp(movil,"Camion")==0){precio=5*0.8;}
                      
                      break;
            }
            cont2++;
            acu=acu+precio;
            vuelto = pago - precio;
            printf("Usted debe %f pago con %f pesos y su vuelto es %f\n",precio, pago, vuelto);
            printf("Desea seguir vendiendo peajes (si/no): \n");
            fflush(stdin);
            gets(inicio);
            system("CLS");
      }
      printf("**********\n");
      printf("*INFORMES*\n");
      printf("**********\n\n");
      
      printf("La cantidad de Peajes vendidos para Autos en Hora pico es: %i\n",cont);
      printf("La cantidad Toral de Peajes vendidos es: %i\n",cont2);
      printf("La Total de Peajes vendidos es: %f\n",acu);
      getch();
}
