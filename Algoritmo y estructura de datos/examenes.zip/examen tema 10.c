/*
Se solicita el siguiente Programa que controle las apuestas de carreras de caballo "TURF". El cual dispone de 4 caballos que corren  en dos turnos.
Se pueden realizar dos  operaciones Ingreso de Apuesta (cod caballo, monto, turno ), Calculo ganador y  Mostrar (Caballo ganador, turno,  cuantos ganaron, total a pagar).
Se Pide:
Crear un men� con las siguientes opciones:
1-	Ingreso: Permite ingresar el c�digo del caballo (Car�cter):
a.	 Tiroloco(paga un 50%  m�s de lo apostado)
b.	Buena vida (paga un 100% m�s de lo apostado).
c.	La yesi (paga un 150% m�s de lo apostado).
d.	El Moro (paga un 200% m�s de lo apostado).
Monto (Real) La apuesta del apostador, Turno (entero)1 = Primera  /  2 = Segunda.
Se deber� implementar una funci�n que reciba:  Cod_caballo, monto, Turno y grabe estos datos en un archivo de texto.
2-	 Calculo Ganador y Mostrar: Permitir� conocer la cantidad de apostadores que acertaron al ganador y el total que debe pagar la casa de apuesta a trav�s de los datos a cargados en el Archivo de texto.

Se deber� implementar una funci�n que reciba por referencia 3 vectores donde se guarden a trav�s de la lectura del archivo, los datos de cada registro (Cod_caballo, turno, monto).

Una vez que se cargaron los 3 vectores, se deber� llamar otra funci�n que reciba por referencia los tres vectores, el cod_caballo ganador y el turno en que corri�, recorrer� los vectores y contara la cantidad de apostadores ganadores retornando este valor. Luego calculara el total a pagar y mostrara ambos resultados por pantalla.

Usar aritm�tica de punteros.

*/
#include<stdio.h>
#include<conio.h>
int menu();
void cargar_datos(char fcod_caba, int fmonto, int fturno, char fnombre[]);
void cargar_ganadores(char *fpcod_caba, int *fpturno);
void calcular_ganador(char *fpcod_caba, int *fpturno, int *fgana, char fcod_caba, int fmonto, int fturno, char fnombre[]);
int tot_final(int *fpgana2, int fx);
main()
{
      int vmenu, monto, turno, tur, gana;
      char cod_caba, nombre[20], cod_c;  
      
      vmenu=menu();
      
      while(vmenu!=0)
      {
         switch(vmenu)
         {
             case 1:
                  cargar_datos(cod_caba, monto, turno, nombre);
                  break;
             case 2:
                  cargar_ganadores(&cod_c, &tur);
                  break;
             case 3:
                  calcular_ganador(&cod_c, &tur, &gana, cod_caba, monto, turno, nombre);
                  break;
         }
      
        vmenu=menu();
      }
      getch();
}
////////////////////////////////////////////////////////////////////////////////
int tot_final(int *fpgana2, int fx)
{
    int tot=0,i;
    
    for(i=0;i<fx;i++)
    {
       tot=tot + *fpgana2;
       *fpgana2++;
    }
    return tot;
}
////////////////////////////////////////////////////////////////////////////////
void calcular_ganador(char *fpcod_caba, int *fpturno, int *fgana,char fcod_caba, int fmonto, int fturno, char fnombre[])
{
     FILE *archivo;
     char a,b;
     int c,d,mfinal,x=0,*p;
     p=fgana;
     a=*fpcod_caba;
     fpcod_caba++;
     b=*fpcod_caba;
     
     c=*fpturno;
     fpturno++;
     d=*fpturno;
          
     archivo=fopen("f:\\turf.txt","r");
     if(archivo!=NULL)
            {
            while(!feof(archivo))
                {
                   fscanf(archivo,"%c\t%i\t%i\t%s\n",&fcod_caba,&fmonto,&fturno,fnombre);
                   if (((a==fcod_caba) && (c==fturno))||((b==fcod_caba) && (d==fturno)))
                   {
                      switch(fcod_caba)
                      {
                          case 'a':
                                   mfinal=fmonto*1.5;
                               break;
                          case 'b':
                                   mfinal=fmonto*2;
                               break;
                          case 'c':
                                   mfinal=fmonto*2.5;
                               break;
                          case 'd':
                                   mfinal=fmonto*3;
                               break;
                      }
                      *fgana=mfinal;
                      fgana++;
                      x++;
                      printf("El Apostados %s gano %i\n", fnombre, mfinal);
                   }  
                }
                printf("\nEl total a Pagar es: %i\n",tot_final(p,x));
            }

      else
            {
            printf("\nError al leer el archivo");
            getch();
            }
        fclose(archivo);
        getch();
        system("CLS");
     
}
////////////////////////////////////////////////////////////////////////////////
void cargar_ganadores(char *fpcod_caba, int *fpturno)
{
     char a,b;
     
     printf("Ingrese el Codigo del Caballo ganador del Primer turno\n");
     fflush(stdin);
     scanf("%c",&a);
     *fpcod_caba=a;
     *fpturno=1;
     fpcod_caba++;
     fpturno++;
     printf("Ingrese el Codigo del Caballo ganador del Segundo turno\n");
     fflush(stdin);
     scanf("%c",&b);
     *fpcod_caba=b;
     *fpturno=2;
     system("CLS");
}
////////////////////////////////////////////////////////////////////////////////
void cargar_datos(char fcod_caba, int fmonto, int fturno, char fnombre[])
{
     FILE * archivo;
     printf("****Menu 1****\n");
     printf("Ingresar Codigo de Caballo\n");
     printf("(a)Tiroloco\n");
     printf("(b)Buena Vida\n");
     printf("(c)La Yesi\n");
     printf("(d)El Moro\n");
     fflush(stdin);
     scanf("%c",&fcod_caba);
     printf("\nIngrese el Monto a Apostar: \n");
     scanf("%i",&fmonto);
     printf("Ingrese el turno\n(1)Primera\n(2)Segunda: \n");
     scanf("%i",&fturno);
     printf("Ingrese el Nombre del Apostador: \n");
     fflush(stdin);
     gets(fnombre);
     system("CLS");
     
         archivo=fopen("f:\\turf.txt","a+");
         if(archivo!=NULL)
            {
            
                fprintf(archivo,"%c\t%i\t%i\t%s\n",fcod_caba,fmonto,fturno,fnombre);//paso los datos de las variables al archivo con
                //printf("\nEL ARCHIVO SE GENERO\n");                           // la funcion fprintf()
                //getch();
                system("CLS");
            }           
        else
            {
            printf("\n--Imposible generar el archivo--");
            getch();
            }
        fclose(archivo);
     
}
////////////////////////////////////////////////////////////////////////////////
int menu()
{
    int inicio;
    //primer menu accines del programa
    printf("Bienvenido a la aplicacion Turf\n");
    printf("1-Ingresar una Apuesta\n");
    printf("2-Ingresar Ganadores\n");
    printf("3-Calcular Ganadores\n");
    printf("0-Salir\n");
    scanf("%i",&inicio);
    system("CLS");
    return (inicio);
}
