/*
Hollycinema, una empresa que cuenta con salas de cine desea una aplicaci�n para poder obtener resultados de las pel�culas que proyecta.
 En  la actualidad proyecta cuatro pel�culas: 1- Coraz�n de Leon. 2-El conjuro. 3-Metegol. 4-Jobs.
En dos turnos con distinto precio: 1-Matine=25$, 2-Normal=50. 
Se sabe que no se puede vender m�s de 40 entradas por pel�cula por dia, y solo una entrada por persona.
A-	Generar el c�digo de entrada autom�ticamente sabiendo que el primero es =0, y que las entradas se venden solo en el d�a y por ventana.
B-	Informar Total vendido de Coraz�n de Le�n en el turno matin�.
C-	Informar El total vendido de todas pel�culas en el turno Normal.
D-	Informa Cantida total de entradas vendidas.
E-	Informar La pel�cula que mas entradas vendi�.
F-	Informar la pel�cula que menos recaudo.

# Resolver todos los c�lculos de las consignas A, B, C, D, E y F usando funciones.  La funci�n que resuelve la consigna A no puede utilizar variables globales.  La funci�n A debe retornar al programa principal el c�digo de entrada.
# La carga finaliza cuando pel�cula en igual a 0.
# Todos los mensajes que se muestren por pantalla deber�n estar prolijos y ordenados. 
#Se ingresa la pel�cula, el turno.


*/
#include<stdio.h>
#include<conio.h>

main()
{
      char ven[2], turno[6];
      int peli, pelim=25, pelin=50,ctev=0,contcdl=0,contec=0,contm=0;
      int acucdl=0,acdl=0,aec=0,am=0,contj=0,aj=0,acun=0,tevn=0, cm=0, cn=0,tot=2,ban1=0, ban2=0;
      
      printf("Desea vender entradas (si/no)");
      fflush(stdin);
      gets(ven);
      system("CLS");
            
       while (strcmp(ven, "si")==0) 
       {
             printf("PELICULAS EN CARTELERA\n");
             printf("1-Corazon de Leon.\n");
             printf("2-El Conjuro.\n");
             printf("3-Metegol.\n");
             printf("4-Jobs.\n");
             scanf("%i",&peli);
             system("CLS");
             printf("Que Funcion Desea matine / normal\n");    
             fflush(stdin);
             gets(turno);
             system("CLS");
             //verificacion de entradas
             if((cn<tot)&&(strcmp(turno, "normal")==0)) 
             {
                 cn=cn+1;
             }
             else if(strcmp(turno, "normal")==0)
             {
                 ban1=1;
                 strcpy(ven,"no");
                 printf("No se pueden vender mas Entradas Normales\n");
                 //system("CLS"); 
             }
             if((cm<tot)&&(strcmp(turno, "matine")==0)) 
             {
                cm=cm+1;
             }
             else if(strcmp(turno, "matine")==0)
             {
                 ban2=1;
                 strcpy(ven,"no");
                 printf("No se pueden vender mas Entradas Matutinas\n");
                // system("CLS"); 
             }
             //            
             
             switch (peli)
             {
                    case 1:
                         contcdl=contcdl+1;
                         if(strcmp(turno, "matine")==0)
                         {
                            acucdl=acucdl+pelim;
                            acdl=acdl+pelim;
                         }
                         else
                         {
                            acdl=acdl+pelin; 
                         }
                    break;
                    
                    case 2:
                         contec=contec+1;
                         if(strcmp(turno, "matine")==0)
                         {
                          aec=aec+pelim;     
                            }
                         else
                         {
                            aec=aec+pelin; 
                            
                         }
                    break;
                    
                    case 3:
                         contm=contm+1;
                         if(strcmp(turno, "matine")==0)
                         {
                          am=am+pelim;     
                            }
                         else
                         {
                            am=am+pelin; 
                         }
                    break;
                    
                    case 4:
                         contj=contj+1;
                         if(strcmp(turno, "matine")==0)
                         {
                          aj=aj+pelim;     
                            }
                         else
                         {
                            aj=aj+pelin; 
                         }
                    break;
              }
              if(strcmp(turno, "normal")==0)
              {
                 acun=acun+pelin;
              }
              //Verifica las banderas
              if((ban1==0)||(ban2==0))
              {
                  printf("Desea vender entradas (si/no)");
                  fflush(stdin);
                  gets(ven);
                  system("CLS"); 
              }
       }
       //total de entradas
       ctev=contcdl+contec+contm+contm;
       tevn=acdl+aec+am+aj;
       //Total de entradas de corazon de leon en matine
       printf("El total de entradas vendidas en Corazon de Leon es %i\n",acucdl);
       //total vendidas de todas las peliculas normal
       printf("El total de entradas vendidas del turno normal es %i\n",tevn);
       //total de todas las entradas vendidas
       printf("La cantidad total de entradas vendidas es %i\n",ctev);
       //pelicula que mas entradas vendio
       if((contcdl>contec)&&(contcdl>contec)&&(contcdl>contm))
       {
          printf("La pelicula que mas entradas vendio es Corazon de Leon\n");                                                                                                                                                   
       }
       else if((contec>contcdl)&&(contec>contm)&&(contec>contm))
            {
                printf("La pelicula que mas entradas vendio es El conjuro\n");                                                                                                                                                   
            }
            else if((contm>contec)&&(contm>contcdl)&&(contm>contm))
                 {
                    printf("La pelicula que mas entradas vendio es Metegol\n");                                                                                                                                                   
                 }
                 else
                 {
                     printf("La pelicula que mas entradas vendio es jobs\n");
                 }
       //pelicula que menos recaudo
       if((acdl<aec)&&(acdl<am)&&(acdl<aj))
       {
          printf("La pelicula que menos recaudo es Corazon de Leon\n");                                                                                                                                                   
       }
       else if((aec<acdl)&&(aec<am)&&(aec<aj))
            {
                printf("La pelicula que mas entradas vendio es El conjuro\n");                                                                                                                                                   
            }
            else if((am<acdl)&&(am<aec)&&(am<aj))
                 {
                    printf("La pelicula que mas entradas vendio es Metegol\n");                                                                                                                                                   
                 }
                 else
                 {
                     printf("La pelicula que mas entradas vendio es jobs\n");
                 }
      getch();
}
