/*
Se solicita efectuar un programa para una m�quina registradora.

La m�quina registradora puede efectuar 2 operaciones b�sicas:
A.	Efectuar c�lculos.
B.	Emitir y grabar operaciones del d�a

A - Efectuar c�lculos:
Cada vez que el operador seleccione esta opci�n, el programa deber� recibir por parte del operador los siguientes datos:
Operando1: un numero real.
Operando2: un numero real.
Tipo de operaci�n: suma, resta, multiplicaci�n y divisi�n.  Cada operaci�n puede ser representada por un car�cter.  Por ejemplo la suma puede indicarse a trav�s del car�cter 's', la resta a trav�s del car�cter 'r', la multiplicaci�n a trav�s del car�cter �m� y la divisi�n a trav�s del car�cter �d�.

Con dichos datos el programa deber�:
1 - Calcular el resultado de la operaci�n solicitada e informarlo por pantalla: se deber� enviar a una funci�n los dos operandos y el car�cter correspondiente al tipo de operaci�n.  La funci�n deber� retornar el resultado y mostralo por pantalla.
2 - Cargar en tres vectores los datos: vector1 el operando1, vector2 el operando2 y vector3 el car�cter correspondiente al tipo de operaci�n.  Se deber�n pasar a la funci�n los tres vectores y los tres datos y la funci�n actualizara los vectores con los tres datos.

B - Emitir y grabar operaciones del d�a
Cuando el operador seleccione esta opci�n al finalizar el d�a, a trav�s de una funci�n a la que se le pasen los tres vectores, el programa deber� recorrerlos en formato puntero y mostrar cada una de las operaciones efectuadas, as� como tambi�n grabarlas en un archivo de texto de la siguiente forma:
 (operando1	operando2	car�cter_correspondiente_al_tipo_de_operaci�n). 

Evitar el uso de variables globales.
Estimar el tama�o de los vectores en 50 posiciones.

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////*/
#include<stdio.h>
#include<conio.h>
#define cant 50
float calculo(float a, float b, char c);
void cargavector(float x, float y, char z, float *vx, float *vy, char *vz, int j);
void cargararchivo(float *vx, float *vy, char *vz);


main()
{
      int inicio=0,opc=0, i=0;
      float ope1=0, ope2=0, vope1[cant]={0}, vope2[cant]={0},resu=0;
      char arit, varit[cant];
      
      while(inicio!=3)
      {
         printf("PROGRAMA CALCULO\n");
         printf("*****************\n\n\n");
         printf("1-Efectuar calculo\n");
         printf("2-Emitir y Grabar operaciones del dia\n");
         printf("3-Salir\n");
         scanf("%i",&opc);
         switch(opc)
         {
             case 1:
                  printf("CALCULO:\n");
                  printf("-------\n\n");
                  printf("Ingresar el Primer Operedaro: \n");
                  scanf("%f",&ope1);
                  printf("Ingresar el Segundo Operedaro: \n");
                  scanf("%f",&ope2);
                  printf("Ingrese la Operacion aritmetica a realizar:\n");
                  printf("s-SUMA\n");
                   printf("r-RESTA\n");
                  printf("m-MULTIPLICACION\n");
                  printf("d-DIVISION\n");
                  scanf("%s",&arit);
                  resu=calculo(ope1,ope2,arit);
                  printf("El resultado de la opetacio es: %f",resu);
                  cargavector(ope1, ope2, arit, vope1, vope2, varit, i);
                  i=i+1;     
                  getch();
                  system("CLS");
                  break;
             case 2:
                  cargararchivo(vope1, vope2, varit);
                  break;
             case 3:
                  inicio=3;
                  break;
         
      }
}
}
////////////////////////////////////////////////////////////////////////////////
void cargararchivo(float *vx, float *vy, char *vz)
{
     FILE *archivo;
     
     archivo=fopen("c:\\operaciones.txt","w");
     if(archivo==NULL)
     {
          printf("Apertura de Archivo erronea");
     }
     else
     {
         for(;*vx;vx++)
         {
            fprintf(archivo,"%f\t %f\t %c\n",*vx,*vy,*vz);
            printf("%f\t %f\t %c\n",*vx,*vy,*vz);
            vy++;
            vz++;
         }
     }
     fclose(archivo);
}
////////////////////////////////////////////////////////////////////////////////
void cargavector(float x, float y, char z, float *vx, float *vy, char *vz, int j)
{
     *(vx+j)=x;
     *(vy+j)=y;
     *(vz+j)=z;
}
////////////////////////////////////////////////////////////////////////////////
float calculo(float a, float b, char c)
{
      float total;
      switch(c)
      {
          case 's':
               total=a+b;
               break;
          case 'r':
               total=a-b;
               break;
          case 'm':
               total=a*b;
               break;
          case 'd':
               total=a/b;
               break;
      }
      return total;
}
