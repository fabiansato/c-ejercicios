/*
Se solicita efectuar el siguiente programa para gestionar los estados de regularidad de los alumnos de una Universidad.
Se pueden realizar dos operaciones: ingreso (ingresa datos de estado para cada alumno por materia y turno) o Estado de regularidad (cantidad de alumnos regulares para una materia y turno determinado). 
Se pide:
Crear un men� con las siguientes opciones:
1 - Ingreso: permitir� al usuario  ingresar C�digo de alumno (un numero entero), C�digo de Materia (un numero entero), turno (M, T, N) y estado de regularidad (R o L).
 Se deber� implementar una funci�n que reciba: c�digo de alumno, c�digo de Materia, turno, estado de regularidad y grabe estos datos en un archivo de texto.
2 - Calcular cantidad alumnos regulares por materia y turno: permitir� conocer la cantidad de alumnos regulares para la materia y turno seleccionado por el operador, contando las operaciones grabadas en el archivo generado en la opci�n 1.
Se deber� implementar una funci�n que reciba por referencia 4 vectores donde se guarden a trav�s de la lectura del archivo, los datos de los campos de cada registro (en el primero solo los c�digos de alumno, en el segundo los c�digos de materia, en el tercero los turnos y en el cuarto los estados de regularidad).  
Una vez que se cargaron los 4 vectores, se deber� llamar a otra funci�n que reciba por referencia los mismos 4 vectores,  la materia seleccionada y el turno seleccionado, recorrer� los vectores y calcular� la cantidad de alumnos regulares, la que deber� ser retornada por la funci�n. 
Usar aritm�tica de punteros.

*/
#include<stdio.h>
#include<conio.h>
#define tam 5
//Prototipo de Funciones
int menu();
void cargar_operaciones(int fcod_alu, int fcod_materia, char fturno, char festado);
void cargar_vectores(int *fcod_alu, int *fcod_materia, char *fturno, char *festado);
int calcular_alumnos_regulares(int *fcod_alu, int *fcod_materia, int fcod_elegido, char *fturno, char *festado, char fturno_elegido);
//inicio del cuerpo del programa
main()
{
       int cod_alu, cod_materia, vcod_alu[tam], vcod_materia[tam], vmenu, cod_elegido;//variables locales al main()
       char turno, estado, vturno[tam], vestado[tam], turno_elegido;
       
       vmenu=menu();//carga opcion del menu()
        while(vmenu!=4)
      {
                      switch(vmenu)
                      {
                          case 1:
                               cargar_operaciones(cod_alu, cod_materia, turno, estado);//llamado a la primer funcion *pasaje por copia*
                          break;
                          case 2:
                               cargar_vectores(vcod_alu, vcod_materia, vturno, vestado);//llamado a la segunda funcion *pasaje por referencia* 
                          break;
                          case 3://tercer menu
                               printf("Elegir un Codigo de Materia \n1 - Matematicas.\n2 - Lengua.\n");
                               fflush(stdin);
                               scanf("%i",&cod_elegido);
                               printf("Escribir El Turno\nMa�ana(m)\nTarde(t)\nNoche(n)\n");
                               fflush(stdin);
                               scanf("%c",&turno_elegido);                           
                               printf("La Cantidad de alumnos regulares para la materia %i en el turno %c: \n", cod_elegido, turno_elegido);
                               printf("%i",calcular_alumnos_regulares(vcod_alu, vcod_materia, cod_elegido, vturno, vestado, turno_elegido));//llamado a la tercer funcion *pasaje por referencia y copia* 
                               getch();
                               system("CLS");
                      }
       vmenu=menu();//llama a la funcion menu() para evitar el bucle while.
                      
      }
}
///////////////////////////////////////////////////////////////////////////////////
int calcular_alumnos_regulares(int *fcod_alu, int *fcod_materia, int fcod_elegido, char *fturno, char *festado, char fturno_elegido)
{
    int i, c1=0;// variables locales a la funcion
    
    for(i=0; i<tam; i++)
    {
             if((*fcod_materia==fcod_elegido)&&(*fturno==fturno_elegido)&&(*festado=='r'))//condicin para validar la eleccion del usuario
             {
                 c1++;//contador                                            
             }
             fcod_alu++;//mueve punteros a la siguiente direccion
             fcod_materia++;// ''
             fturno++; //  ''
             festado++;// ''
    }
    
    return c1;//retorna cantidad de tipo int
}
//////////////////////////////////////////////////////////////////////////////////
void cargar_vectores(int *fcod_alu, int *fcod_materia, char *fturno, char *festado)
{
   FILE * archivo;
   
        archivo=fopen("e:\\alumnos.txt","r");//abre el archivo para leerlo
        if(archivo!=NULL)
            {
            while(!feof(archivo))
                {
                //fflush(stdin);
                fscanf(archivo,"%i\t%i\t%c\t%c\n",fcod_alu,fcod_materia,fturno,festado);//carga los registros en los punteros
                printf("%i\t%i\t%c\t%c\n",*fcod_alu,*fcod_materia,*fturno,*festado);//verifica que los valores del archivo esta en los vectores mostrandolos atraves de la pantalla 
                fcod_alu++;//muevo los punteros a la siguiente direccion
                fcod_materia++;// ''
                fturno++;// ''
                festado++;// ''
                }
             printf("Se cargaron los vectores");   
             getch();
             system("CLS");
            }             
        else
            {
            printf("\nError al leer el archivo");
            getch();
            }
        fclose(archivo);//siempre cerrar el archivo           
}
/////////////////////////////////////////////////////////////////////////////////
void cargar_operaciones(int fcod_alu, int fcod_materia, char fturno, char festado)
{
     FILE *archivo;
     //Data a cargar segundo menu
     printf("Escribir El Codigo de Alumno: \n");
     scanf("%i",&fcod_alu);
     printf("Escribir El Codigo de Materia\n1 - Matematicas.\n2 - Lengua.\n");
     scanf("%i",&fcod_materia);
     printf("Escribir El Turno\nMa�ana(m)\nTarde(t)\nNoche(n)\n");
     fflush(stdin);
     scanf("%c",&fturno);
     printf("Escribir El Estado de alumno\nRegular(r)\nLibre(l)\n");
     fflush(stdin);
     scanf("%c",&festado);
     
        archivo=fopen("e:\\alumnos.txt","a+");//abro el archivo
        
        if(archivo!=NULL)
            {
            
                fprintf(archivo,"%i\t%i\t%c\t%c\n",fcod_alu,fcod_materia,fturno,festado);//paso los datos de las variables al archivo con
                printf("\nEL ARCHIVO SE GENERO\n");                           // la funcion fprintf()
                getch();
                system("CLS");
            }           
        else
            {
            printf("\n--Imposible generar el archivo--");
            getch();
            }
        fclose(archivo);//cierro archivo
}    

////////////////////////////////////////////////////////////////////////////////
int menu()
{
    int inicio;
    //primer menu accines del programa
    printf("Bienvenido a la aplicacion....... \nESTADO DE REGULARIDAD DE LOS ALUMNOS\n\n\n");
    printf("1-Cargar Ingreso\n");
    printf("2-Cargar Vectores con Info de Archivo\n");
    printf("3-Calcular y mostrar **\nCantidad de Alumnos Regulares\n");
    printf("4-Salir\n");
    scanf("%i",&inicio);
    system("CLS");
    return (inicio);//retorno la opcion elegida
}
