/*
Se solicita el siguiente Programa que controle las apuestas de carreras de caballo "TURF". 
Se dispone de 4 caballos que corren en dos turnos.
Se pueden realizar tres operaciones:
1 - Ingreso de apuesta.
2 - Ingreso de caballos ganadores.
3 - Calculo de apostadores ganadores.
Se Pide:
Crear un men� con las siguientes opciones:
1-	Ingresar apuestas: permite cargar:
I-El c�digo del caballo al que se apuesta:
a.	 Tiroloco.
b.	Buena vida.
c.	La yesi.
d.	El Moro.
II-El monto apostado ($).
III-El turno de la carrera (1 = Primera  /  2 = Segunda).
IV- El nombre del apostador.
Se deber� implementar una funci�n que reciba estos cuatro datos y los grabe en un archivo de texto.
2-	Ingreso de turno y caballo ganador: permitir� cargar en el programa el caballo que gan� en cada turno.  
Implementar una funci�n que reciba dos variables por referencia y grabe en c/u de ellas el c�digo del caballo ganador en cada turno.
 
3-	Calculo de apostadores ganadores: permitir� conocer los apostadores que acertaron al caballo ganador para cada turno, cuanto se le debe pagar a c/u, y el total que debe pagar la casa de apuestas para ambos turnos.

Se deber� implementar una funci�n que reciba por referencia las dos variables con el caballo ganador en cada turno y 1 vector donde se guardaran los montos a pagar a cada apostador.
Dentro de la funci�n se efectuar� la lectura de todos los registros del archivo, para ver si cada apuesta corresponde al caballo ganador (tambi�n se debe verificar el turno), en tal caso se mostrar� por pantalla el nombre del apostador, y el importe a pagarle seg�n el siguiente esquema:
a.	 Tiroloco (paga un 50%  m�s de lo apostado)
b.	Buena vida (paga un 100% m�s de lo apostado).
c.	La yesi (paga un 150% m�s de lo apostado).
d.	El Moro (paga un 200% m�s de lo apostado).
En el vector se deber� cargar el importe a pagarle al apostador.

Una vez que se leyeron todos los registros y se carg� el vector, se deber� llamar a otra funci�n que reciba por referencia el mismo, y recorri�ndolo calcule el total a pagar por la casa.

Usar aritm�tica de punteros y pasajes por referencia en las funciones.


*/
#include<stdio.h>
#include<conio.h>
int menu();
void cargar_datos(char fcod_caba, int fmonto, int fturno, char fnombre[]);
void cargar_ganadores(char *fpcod_caba, int *fpturno);
void calcular_ganador(char *fpcod_caba, int *fpturno, int *fgana, char fcod_caba, int fmonto, int fturno, char fnombre[]);
int tot_final(int *fpgana2, int fx);
main()
{
      int vmenu, monto, turno, tur, gana;
      char cod_caba, nombre[20], cod_c;  
      
      vmenu=menu();
      
      while(vmenu!=0)
      {
         switch(vmenu)
         {
             case 1:
                  cargar_datos(cod_caba, monto, turno, nombre);
                  break;
             case 2:
                  cargar_ganadores(&cod_c, &tur);
                  break;
             case 3:
                  calcular_ganador(&cod_c, &tur, &gana, cod_caba, monto, turno, nombre);
                  break;
         }
      
        vmenu=menu();
      }
      getch();
}
////////////////////////////////////////////////////////////////////////////////
int tot_final(int *fpgana2, int fx)
{
    int tot=0,i;
    
    for(i=0;i<fx;i++)
    {
       tot=tot + *fpgana2;
       *fpgana2++;
    }
    return tot;
}
////////////////////////////////////////////////////////////////////////////////
void calcular_ganador(char *fpcod_caba, int *fpturno, int *fgana,char fcod_caba, int fmonto, int fturno, char fnombre[])
{
     FILE *archivo;
     char a,b;
     int c,d,mfinal,x=0,*p;
     p=fgana;
     a=*fpcod_caba;
     fpcod_caba++;
     b=*fpcod_caba;
     
     c=*fpturno;
     fpturno++;
     d=*fpturno;
          
     archivo=fopen("f:\\turf.txt","r");
     if(archivo!=NULL)
            {
            while(!feof(archivo))
                {
                   fscanf(archivo,"%c\t%i\t%i\t%s\n",&fcod_caba,&fmonto,&fturno,fnombre);
                   if (((a==fcod_caba) && (c==fturno))||((b==fcod_caba) && (d==fturno)))
                   {
                      switch(fcod_caba)
                      {
                          case 'a':
                                   mfinal=fmonto*1.5;
                               break;
                          case 'b':
                                   mfinal=fmonto*2;
                               break;
                          case 'c':
                                   mfinal=fmonto*2.5;
                               break;
                          case 'd':
                                   mfinal=fmonto*3;
                               break;
                      }
                      *fgana=mfinal;
                      fgana++;
                      x++;
                      printf("El Apostados %s gano %i\n", fnombre, mfinal);
                   }  
                }
                printf("\nEl total a Pagar es: %i\n",tot_final(p,x));
            }

      else
            {
            printf("\nError al leer el archivo");
            getch();
            }
        fclose(archivo);
        getch();
        system("CLS");
     
}
////////////////////////////////////////////////////////////////////////////////
void cargar_ganadores(char *fpcod_caba, int *fpturno)
{
     char a,b;
     
     printf("Ingrese el Codigo del Caballo ganador del Primer turno\n");
     fflush(stdin);
     scanf("%c",&a);
     *fpcod_caba=a;
     *fpturno=1;
     fpcod_caba++;
     fpturno++;
     printf("Ingrese el Codigo del Caballo ganador del Segundo turno\n");
     fflush(stdin);
     scanf("%c",&b);
     *fpcod_caba=b;
     *fpturno=2;
     system("CLS");
}
////////////////////////////////////////////////////////////////////////////////
void cargar_datos(char fcod_caba, int fmonto, int fturno, char fnombre[])
{
     FILE * archivo;
     printf("****Menu 1****\n");
     printf("Ingresar Codigo de Caballo\n");
     printf("(a)Tiroloco\n");
     printf("(b)Buena Vida\n");
     printf("(c)La Yesi\n");
     printf("(d)El Moro\n");
     fflush(stdin);
     scanf("%c",&fcod_caba);
     printf("\nIngrese el Monto a Apostar: \n");
     scanf("%i",&fmonto);
     printf("Ingrese el turno\n(1)Primera\n(2)Segunda: \n");
     scanf("%i",&fturno);
     printf("Ingrese el Nombre del Apostador: \n");
     fflush(stdin);
     gets(fnombre);
     system("CLS");
     
         archivo=fopen("f:\\turf.txt","a+");
         if(archivo!=NULL)
            {
            
                fprintf(archivo,"%c\t%i\t%i\t%s\n",fcod_caba,fmonto,fturno,fnombre);//paso los datos de las variables al archivo con
                //printf("\nEL ARCHIVO SE GENERO\n");                           // la funcion fprintf()
                //getch();
                system("CLS");
            }           
        else
            {
            printf("\n--Imposible generar el archivo--");
            getch();
            }
        fclose(archivo);
     
}
////////////////////////////////////////////////////////////////////////////////
int menu()
{
    int inicio;
    //primer menu accines del programa
    printf("Bienvenido a la aplicacion Turf\n");
    printf("1-Ingresar una Apuesta\n");
    printf("2-Ingresar Ganadores\n");
    printf("3-Calcular Ganadores\n");
    printf("0-Salir\n");
    scanf("%i",&inicio);
    system("CLS");
    return (inicio);
}
