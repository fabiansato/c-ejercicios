/*
Se solicita efectuar el siguiente programa para movimientos de stock de dos almacenes. Ambas almacenes cuentan con un stock inicial de 5000 unidades. Almac�n1 (resmas=5000), Almacen2 (T�ner=5000). Dentro de los stock se pueden realizar don operaciones ingreso(Aumenta el stock) o Egreso(Disminuye el Stock). 
El usuario debe ingresar Almac�n 1 o 2, operaci�n (i=ingreso/e=egreso),  cantidad (que ingresara o se sacara dependiendo la operaci�n).
Calculo:
El operador debe elegir una almac�n y un tipo de movimiento, tambi�n debe ingresa la cantidad, y en base a la operaci�n restarle o sumarle la cantidad de stock dejando el stock actualizado un ejemplo de ingreso seria:  1	i	150	
Realizar una funci�n que pase por referencia : el numero de almac�n, la operaci�n, la cantidad , el stock, y devuelva el stock actualizado.
Cargar 4 vectores donde en el primero se guarden solo los n�meros de almac�n, otro donde guarde la operaci�n, otro donde guarde la cantidad, otro donde guarde la variaciones de stock. Realizarlo con funciones y pasaje por referencia. Usar aritm�tica de punteros.
Antes de finalizar el programa el programa debe guardar a trav�s de una funci�n donde pase los 4 vectores cargados y los grave en un archivo de texto en el siguiente orden:
Almac�n	operaci�n	cantidad	Stock
 Por �ltimo debe abrir el archivo ya guardado, recorrerlo y mostrar los resultados cargados, utilizar funciones.

*/

#include<conio.h>
#include<stdio.h>
#define tam 5
//Prototipo de Funciones
int menu();
void cargar_operacion(int falmacen, int fcantidad, char foperacion);
void cargar_vectores(int *falm, int *fcant, char *fop);
int calcular_mostrar(int *falm, int *fcant, char *fop, int felegido);
//inicio del cuerpo del programa
main()
{
      int almacen, cantidad, alm[tam], cant[tam], elegido,vmenu;//variables locales al mail()
      char operacion, op[tam];
      
      vmenu=menu();//carga opcion del menu()
      while(vmenu!=4)
      {
                      switch(vmenu)
                      {
                          case 1:
                               cargar_operacion(almacen, cantidad, operacion);
                          break;
                          case 2:
                               cargar_vectores(alm, cant, op);
                          break;
                          case 3:
                               printf("Ingresar el almacen del cual desee calcular stock: \n");
                               fflush(stdin);
                               scanf("%i",&elegido);
                               printf("La almacen elegida: %i \ntiene un stock final de: %i \n", elegido, calcular_mostrar(alm, cant, op, elegido));
                               getch();
                               system("CLS");
                      }
       vmenu=menu();
                      
      }
}
////////////////////////////////////////////////////////////////////////////////
//DESARROLO DE FUNCIONES////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
int calcular_mostrar(int *falm, int *fcant, char *fop, int felegido)
{
    int i=0, stock=0;
    //inicializa el stock dependiendo el almacen
    if(felegido==1)
      {
        stock=5000;//es dato del enunciado, lo ideal seria usar Define en una variable
      }
    else
      {
        stock=5000;
      } 
    //fin inicializacion de almacen
    //Se hace el calculo para el tama�o, Seteado en la variable define "tam"
    for(i=0;i<tam;i++)
    {
      switch(felegido)//en funcion de lo  que eligio el usuario
      {
         case 1://aritmetica de punteros
                if((felegido==*falm)&&(*fop=='i'))
                {
                   stock=stock+(*fcant);
                }
                else if((felegido==*falm)&&(*fop=='e'))
                {
                     stock=stock-(*fcant);
                }
         break;
         case 2://aritmetica de punteros
                if((felegido==*falm)&&(*fop=='i'))
                {
                   stock=stock+(*fcant);
                }
                else if((felegido==*falm)&&(*fop=='e'))
                {
                     stock=stock-(*fcant);
                }
         break;
      }//muevo los tres punteros al mismo tiempo, ya que trabajan como un registro
      falm++;
      fcant++;
      fop++;
    }
    return stock;
}
////////////////////////////////////////////////////////////////////////////////
void cargar_vectores(int *falm, int *fcant, char *fop)
{
   FILE * archivo;
   
        archivo=fopen("e:\\stocks.txt","r");//abre el archivo para leerlo
        if(archivo!=NULL)
            {
            while(!feof(archivo))
                {
                //fflush(stdin);
                fscanf(archivo,"%i\t%c\t%i\n",falm,fop,fcant);//carga los registros en los punteros
                printf("%d\t\t%c\t%d\n",*falm,*fop,*fcant);//verifica que los valores del archivo esta en los vectores
                falm++;//muevo los punteros a la siguiente direccion
                fop++;
                fcant++;
                }
             printf("Se cargaron los vectores");   
             getch();
             system("CLS");
            }             
        else
            {
            printf("\nError al leer el archivo");
            getch();
            }
        fclose(archivo);//siempre cerrar el archivo           
}
////////////////////////////////////////////////////////////////////////////////
void cargar_operacion(int falmacen, int fcantidad, char foperacion)
{
     FILE *archivo;
     //Data a cargar
     printf("Elija la almacen (1 - 2): \n");
     scanf("%i",&falmacen);
     printf("Elija una Operacion (i)ingreso - (e)egreso: \n");
     fflush(stdin);
     scanf("%c",&foperacion);
     printf("Ingrese la Cantidad: \n");
     scanf("%i",&fcantidad);
     
        archivo=fopen("e:\\stocks.txt","a+");//abro el archivo
        
        if(archivo!=NULL)
            {
            
                fprintf(archivo,"%i\t%c\t%i\n",falmacen,foperacion,fcantidad);//paso los datos de las variables al archivo con
                printf("\nEL ARCHIVO SE GENERO\n");                           // la funcion fprintf()
                getch();
                system("CLS");
            }           
        else
            {
            printf("\n--Imposible generar el archivo--");
            getch();
            }
        fclose(archivo);//cierro archivo
}
////////////////////////////////////////////////////////////////////////////////
int menu()
{
    int inicio;
    //primer menu accines del programa
    printf("Bienvenido a la aplicacion Stock\n");
    printf("1-Cargar Operacion\n");
    printf("2-Cargar Vectores con Info de Archivo\n");
    printf("3-Calcular y mostrar Stock\n");
    printf("4-Salir\n");
    scanf("%i",&inicio);
    system("CLS");
    return (inicio);//retorno la opcion elegida
}
