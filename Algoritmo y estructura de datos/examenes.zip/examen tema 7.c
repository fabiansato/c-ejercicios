/*
Ejercicio

Se desea hacer una aplicaci�n que controle la venta de una trilog�a de pel�cula en dvd.
 
La pel�cula se llama Ip Man 1, Ip Man 2 e Ip Man 3. 

Se sabe que en stock hay 80 pel�culas de cada parte de la trilog�a.

Las pel�culas cuestan 250 pesos por separado pero hay una promoci�n por la compra de la trilog�a (si se compran las tres pel�culas juntas cuestan 600).

Se pide:
Que el programa consulte al operador por cual � cuales pel�culas es la venta.

La aplicaci�n debe averiguar si hay stock para la venta � no (ya sea si lleva una, dos, o las tres).

En el caso de que no haya stock para al menos una de las pel�culas solicitadas, no se efectuar� la venta y deber� informar para cual � cuales de las pel�culas
 pedidas no hay stock.

En el caso que haya stock de todas las pel�culas solicitadas se efect�a la venta y se debe informar el valor a pagar (dependiendo de si lleva una, 
dos � las tres).

El programa termina su ejecuci�n cuando se quede sin stock de las tres pel�culas � cuando el usuario le indique que no quiere vender m�s.

Notas: 
-	Por cada venta no puede llevar m�s de una pel�cula de cada una.
-	Para saber si hay � no stock de cada pel�cula el programa principal se lo preguntar� a una funci�n (una funci�n de consulta de stock para cada pel�cula).
-	El valor de la venta ser� obtenido por el programa principal mediante una funci�n que reciba la cantidad de cada pel�cula que lleva (0 � 1).
-	Para informar el importe de la venta se debe efectuar mediante una funci�n que primero limpie la pantalla y luego lo informe.


Todos los mensajes que se muestren por pantalla deben estar prolijamente ordenados y distribuidos.


No se pide:
Validaci�n de entradas, asumimos que el operador ingresa todos los datos de forma correcta.

*/
#include<stdio.h>
#include<conio.h>
#include<string.h>
#include<stdlib.h>
int haystock1();
int haystock2();
int haystock3();
float valor(int c1,int c2,int c3);
void mostrar(float val);
int stock1,stock2,stock3;
int main(){
    int ip1,ip2,ip3;
    char continua[3]={"si"};
    stock1=2;
    stock2=2;
    stock3=1;
    int novender;
    while ((strcmp("no",continua)) && ((stock1+stock2+stock3)>0)){
          printf("\t\t\nDesea llevar ip1?(1-si,0-no)");
          fflush(stdin);
          scanf("%d",&ip1);
          printf("\t\t\nDesea llevar ip2?(1-si,0-no)");
          fflush(stdin);
          scanf("%d",&ip2);
          printf("\t\t\nDesea llevar ip3?(1-si,0-no)");
          fflush(stdin);
          scanf("%d",&ip3);
          novender=1;
          if (ip1>0){
                     if (!(haystock1())){
                                         printf("\t\t\nNo hay stock de ip1");
                                         novender=0;
                                      }                 
                     }
          if (ip2>0){
                     if (!(haystock2())){
                                         printf("\t\t\nNo hay stock de ip2");
                                         novender=0;
                                      }                 
                     }
          if (ip3>0){
                     if (!(haystock3())){
                                         printf("\t\t\nNo hay stock de ip3");
                                         novender=0;
                                      }                 
                     }
          
          if (novender){
          if (ip1>0){
                     stock1--;}
          if (ip2>0){
                     stock2--;}
          if (ip3>0){
                     stock3--;}
                 mostrar(valor(ip1,ip2,ip3));       
                        
                        }
          system("pause");
          printf("\t\tDesea continuar vendiendo? \n");
          fflush(stdin);
          gets(continua);
          }
    
    
    }
    
int haystock1(){
   if (stock1){
               return 1;}else{
                      return 0;}
    }
int haystock2(){
   if (stock2){
               return 1;}else{
                      return 0;}
    }
   
int haystock3(){
   if (stock3){
               return 1;}else{
                      return 0;}
    }
float valor(c1,c2,c3){
      if ((c1+c2+c3)==3){
                        return 600;}else {
                              return (c1+c2+c3)*250;}
    }
void mostrar(float val){
     system("cls");
     printf("\t\t\nEl valor a abonar es: %.2f",val);
     }
