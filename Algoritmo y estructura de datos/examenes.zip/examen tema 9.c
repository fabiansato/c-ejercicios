/*
Codificar un programa para gestionar las ventas de una concesionaria de autos:
Los datos a ingresar son:
"	Marca (solo Ford y VW).
"	A�o.
"	Vendedor (solo hay 2 vendedores).
"	Importe de la venta.
Se ingresaran ventas mientras el operador lo desee y cuando decida no seguir cargando ventas, el programa deber� mostrar:

1er turno de alumnos:
"	Total de ventas por vendedor en importe y cantidad.
"	Total de veh�culos marca Ford vendidos (detallar total general y cu�l de los dos vendedores vendi� m�s).
"	Hacer pasos de resoluci�n del problema, diagrama de flujo y c�digo en lenguaje c.
"	No hacer validaci�n de entradas.
*/
#include<stdio.h>
#include<conio.h>

main()
{
      char marca[5], inicio[3]={"si"};
      int year, vendedor,cv1=0,cv2=0,cmf=0,cvg=0;
      float importe,acuv1=0,acuv2=0;
      
      printf("Ventas de Autos\n");
      printf("****************\n");
      system("PAUSE");
      
      //while(strcmp("si",inicio)==0)
       while(!strcmp("si",inicio))
      
      {
         printf("Ingresar Marca del auto a vender (Ford/VW): ");
         fflush(stdin);
         gets(marca);
         printf("\nIngresar el a�o: ");
         scanf("%i",&year);
         printf("\ningresar Numero de Vendedor (1/2): ");  
         scanf("%i",&vendedor);
         printf("\nIngresar el Importe de la Venta: ");  
         scanf("%f",&importe);
         if(vendedor==1)
         {
             cv1=cv1+1;
             acuv1=acuv1+importe;
         }
         else
         {
             cv2=cv2+1;
             acuv2=acuv2+importe;
         }
         
         if(strcmp(marca,"Ford")==0)
         {
             cmf=cmf+1;
         }
         cvg=cvg+1;
         system("CLS");//limpia pantalla
         printf("\nDesea realizar otra venta (si/no)");
         fflush(stdin);
         gets(inicio);
         system("CLS");
      }      
      printf("Resultados\n");
      printf("**********\n\n");
      printf("El vendedor 1 vendio una cantidad de %i de autos y recaudo un total %f\n",cv1,acuv1);
      printf("El vendedor 2 vendio una cantidad de %i de autos y recaudo un total %f\n",cv2,acuv2);
      if(acuv1>acuv2)
      {
          printf("El vendedor 1 es el que mas vendio!!!!!!\n");
      }
      else
      {
          if (acuv1<acuv2)
          {
             printf("El vendedor 2 es el que mas vendio!!!!!!\n");
          }
          else
          {
             printf("Los vendedores vendieron la misma cantidad!!!!!!\n");
          }
      }
      printf("El total de ventas de la marca Ford es %i de el total general %i", cmf, cvg);
      getch();
}
