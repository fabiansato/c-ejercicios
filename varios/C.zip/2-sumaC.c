#include<stdio.h>
#include<stdlib.h>

main()
{
    int a=2;
    int b=3;
    int c;
    c=a+b;
    printf("%d + %d= %d",a,b,c);
}
