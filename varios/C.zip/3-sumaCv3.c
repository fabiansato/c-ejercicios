#include<stdio.h>
#include<stdlib.h>

main()
{
    int a,b,c;
    printf("Ingrese un numero: ");
    scanf("%d",&a);
    printf("Ingrese otro numero: ");
    scanf("%d",&b);
    c=a+b;
    printf("%d + %d= %d",a,b,c);
}
