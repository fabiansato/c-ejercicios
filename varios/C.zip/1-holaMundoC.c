#include<stdio.h>
#include<stdlib.h>

main()
{
    printf("Hola Mundo");
}
